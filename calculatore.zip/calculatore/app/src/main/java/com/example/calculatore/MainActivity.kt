package com.example.calculatore

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    private var lastNumiric = false
    private var tvInput :TextView?=null
    private var txtResult :TextView?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvInput = findViewById(R.id.tvInput)
        txtResult = findViewById(R.id.textResult)
    }

    fun onDigit(view: View) {
        tvInput?.append((view as Button).text)
        lastNumiric = true

    }

    fun onClear(view: View) {
        tvInput?.text = ""
        lastNumiric = false
    }


    fun onOperator(view: View) {

        if(!operatorExist(tvInput?.text.toString()) && lastNumiric){
            tvInput?.append((view as Button).text)
            lastNumiric = false
        }

    }


    private fun operatorExist(value : String) : Boolean{

        return if (value.startsWith("-")) {
             false
            } else{(value.contains("-")||
                value.contains("+")||
                value.contains("/")||
                value.contains("*"))
            }

    }

    fun eqauls(view: View) {

        if(lastNumiric){

            var result = tvInput?.text.toString()
            var negative = ""

            if(result.startsWith("-")){
                result = result.substring(1)
                negative = "-"
            }

                when{
                    (result.contains("/")) ->{

                        var resultSplited = result.split("/")
                        var one = resultSplited[0]
                        var two = resultSplited[1]

                        if(negative.isNotEmpty()){
                            one = negative + one
                        }

                        result = (one.toDouble()/two.toDouble()).toString()

                    }
                    (result.contains("*")) ->{

                        var resultSplited = result.split("*")
                        var one = resultSplited[0]
                        var two = resultSplited[1]

                        if(negative.isNotEmpty()){
                            one = negative + one
                        }

                        result = (one.toLong()*two.toLong()).toString()

                    }
                    (result.contains("-")) ->{

                            var resultSplited = result.split("-")
                            var one = resultSplited[0]
                            var two = resultSplited[1]

                            if(negative.isNotEmpty()){
                                one = negative + one
                            }

                            result = (one.toDouble()-two.toDouble()).toString()

                        }
                    (result.contains("+")) ->{

                            var resultSplited = result.split("+")
                            var one = resultSplited[0]
                            var two = resultSplited[1]

                            if(negative.isNotEmpty()){
                                one = negative + one
                            }

                            result = (one.toDouble()+two.toDouble()).toString()

                        }

                }
            tvInput?.text= result
        }
    }


}